package com.example.Product_Service.service;

import com.example.Product_Service.DAO.ProductDAO;
import com.example.Product_Service.dto.ProductDTO;
import com.example.Product_Service.model.Product;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ProductService{
    @Autowired
    private ProductDAO productDAO;

    @Autowired
    private ModelMapper modelMapper;

    public Product addNewProduct(Product product){

        return productDAO.save(product);
    }

    public List<Product> getAllProducts()
    {

        return (List<Product>)productDAO.findAll();
    }

    public void deleteProduct(Long productId)
    {
        productDAO.deleteById(productId);
    }

    public List<Product> getProductsByCategory(String category) {

        return productDAO.findByCategory(category);
    }
    public List<Product> getProductsByCategoryAndSubcategory1(String category, String subcategory1) {
        return productDAO.findByCategoryAndSubcategory1(category, subcategory1);
    }
    public List<Product> getProductsByCategoryAndSubcategory1AndSubcategory2(String category, String subcategory1, String subcategory2) {
        return productDAO.findByCategoryAndSubcategory1AndSubcategory2(category, subcategory1, subcategory2);
    }

    public Product getProductDetailsById(Long productId)
    {

        return productDAO.findById(productId).get();
    }



    public List<Product> getProductDetailsByEmail(String email) {
        return productDAO.findBySellerEmailID(email);
    }
    public int getProductCount() {
		List<Product> products=(List<Product>) productDAO.findAll();
		return products.size();
	}
}
